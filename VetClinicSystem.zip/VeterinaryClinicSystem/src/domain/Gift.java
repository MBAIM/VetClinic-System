/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domain;

/**
 *
 * @author MORRIS
 */
public class Gift {
     private String giftID;
    private String giftTitle;
    private Double unitPrice;
    private String giftDesp;

    public Gift() {
    }

    public Gift(String giftID, String giftTitle, Double unitPrice, String giftDesp) {
        this.giftID = giftID;
        this.giftTitle = giftTitle;
        this.unitPrice = unitPrice;
        this.giftDesp = giftDesp;
    }

    public String getGiftDesp() {
        return giftDesp;
    }

    public void setGiftDesp(String itemDesp) {
        this.giftDesp = itemDesp;
    }

    public String getGiftID() {
        return giftID;
    }

    public void setGiftID(String itemID) {
        this.giftID = itemID;
    }

    public String getGiftTitle() {
        return giftTitle;
    }

    public void setGiftTitle(String itemTitle) {
        this.giftTitle = itemTitle;
    }

    public Double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(Double unitPrice) {
        this.unitPrice = unitPrice;
    }

    public Object[] getObjects() {
        Object[] objList ={giftID,giftTitle,unitPrice,giftDesp};
        return objList;
    }
    
    
    
}
