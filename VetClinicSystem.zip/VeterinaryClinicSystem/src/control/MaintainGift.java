/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

/**
 *
 * @author MORRIS
 * 
 * 
 */
import da.GiftDA;
import domain.Gift;
import java.util.ArrayList;
public class MaintainGift {
    private GiftDA giftDA;
    
    public MaintainGift()
    {
        giftDA = new GiftDA();
    }
    
    public void addRecord(Gift ser)
    {
        giftDA.addRecord(ser);
    }
    
    public Gift searchRecord(String ID)
    {
        return giftDA.getRecord(ID);
    }
 
    public ArrayList<Gift> searchRecord(String queryStr, int option)
    {
        return giftDA.getRecord(queryStr, option);
    }
    
    public void updateRecord(Gift ser)
    {
        giftDA.updateRecord(ser);
    }
    
    public void deleteRecord(String ID)
    {
        giftDA.deleteRecord(ID);
    }
    
}
