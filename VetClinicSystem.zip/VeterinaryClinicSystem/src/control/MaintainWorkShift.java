//
//package control;
//
//import da.WorkShiftDA;
//import domain.WorkShift;
//
//public class MaintainWorkShift {
//    
//    private WorkShiftDA workshiftDA;
//    
//    public MaintainWorkShift()
//    {
//        workshiftDA = new WorkShiftDA();
//    }
//    
//    public void addRecord(WorkShift workshift)
//    {
//        workshiftDA.addRecord(workshift);
//    }
//    
//    public WorkShift searchRecord(String IC)
//    {
//        return workshiftDA.getRecord(IC);               //WTf?
//    }
//    
//    public void updateRecord(WorkShift workshift)
//    {
//        workshiftDA.updateRecord(workshift);
//    }
//    
//    public void deleteRecord(String IC)
//    {
//        workshiftDA.deleteRecord(IC);
//    }
//}
