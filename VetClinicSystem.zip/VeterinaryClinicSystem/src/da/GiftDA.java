/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package da;

/**
 *
 * @author MORRIS
 */
import domain.Customer;
import domain.Gift;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.*;

public class GiftDA {
    private String url = "jdbc:mysql://localhost:3306/vetexpe";
    private String user = "root";
    private String password = "";
    private String tableName = "gift";
    
    private Connection conn;
    private PreparedStatement stmt;
    
    public GiftDA()
    {
        createConnection();
    }
    
    public void createConnection()
    {
        try
        {
            conn = DriverManager.getConnection(url, user, password);
            System.out.println("***Vet : Connection established.");
        }
        catch(SQLException ex)
        {
            JOptionPane.showMessageDialog(null, ex.getMessage(),"Error",JOptionPane.ERROR_MESSAGE);
        }
    }
     public void addRecord(Gift gift)
    {
        String insertStr = "INSERT INTO " + tableName + " VALUES(?,?,?,?)";
        try
        {
            stmt = conn.prepareStatement(insertStr);
            stmt.setString(1, gift.getGiftID());
            stmt.setString(2, gift.getGiftTitle());
            stmt.setDouble(3, gift.getUnitPrice());
            stmt.setString(4, gift.getGiftDesp());
            
            
            stmt.executeUpdate();
   
        }
        catch(SQLException ex)
        {
            JOptionPane.showMessageDialog(null, ex.getMessage(),"Error",JOptionPane.ERROR_MESSAGE);
        }
    }
     
     public void updateRecord(Gift gift)
    {
        String updateStr = "UPDATE " + tableName + "SET giftid = ?, gifttitle = ?, unitprice = ?, giftdescription = ? "+" WHERE giftid = ? ";
        try
        {
            stmt = conn.prepareStatement(updateStr);
              stmt.setString(1, gift.getGiftID());
            stmt.setString(2, gift.getGiftTitle());
            stmt.setDouble(3, gift.getUnitPrice());
            stmt.setString(4, gift.getGiftDesp());

            stmt.executeUpdate();
   
        }
        catch(SQLException ex)
        {
            JOptionPane.showMessageDialog(null, ex.getMessage(),"Error",JOptionPane.ERROR_MESSAGE);
        }
    }
     
     public Gift getRecord(String giftID)
    {
        String queryStr="SELECT * FROM "+ tableName +" WHERE giftID = ?";
        Gift gift = null;
        try
        {
            stmt = conn.prepareStatement(queryStr);
            stmt.setString(1,giftID);
            ResultSet rs = stmt.executeQuery();
            
            if(rs.next())
            {
                gift = new Gift(giftID,rs.getString("gifttitle"),rs.getDouble("unitprice"),rs.getString("giftdesp")); 
                
            }
        }
        catch(SQLException ex)
        {
            JOptionPane.showMessageDialog(null,ex.getMessage(),"ERROR",JOptionPane.ERROR_MESSAGE);
        }
        return gift;
    }
     
     public ArrayList<Gift> getRecord(String searchStr, int option)
    {
        String queryStr=null;
        Gift gift = null;
        
        switch(option){
            case 0: queryStr= "SELECT * FROM "+ tableName ;
            break;
            case 1: queryStr= "SELECT * FROM "+ tableName +" WHERE LOWER(giftid) = LOWER(?) ";
            break;
            case 2: queryStr="SELECT * FROM "+ tableName +" WHERE LOWER(gifttitle)  LIKE LOWER('%' || ? || '%')";
            break;

        }
        
        ArrayList<Gift> giftList = new ArrayList<Gift>();
        try
        {
            stmt = conn.prepareStatement(queryStr);
            if(option!=0){
            stmt.setString(1,searchStr);
            }
            ResultSet rs = stmt.executeQuery();
            
            while(rs.next())
            {
                giftList.add(new Gift(rs.getString("giftID"),rs.getString("gifttitle"),rs.getDouble("unitprice"),rs.getString("giftdesp"))); 
                
            }
        }
        catch(SQLException ex)
        {
            JOptionPane.showMessageDialog(null,ex.getMessage(),"ERROR",JOptionPane.ERROR_MESSAGE);
        }
        return giftList;
    }
     
       public void deleteRecord(String giftID)
    {
        try
        {
            String deleStr = "DELETE FROM " + tableName + " WHERE giftid = ?";
            
            stmt = conn.prepareStatement(deleStr);
            stmt.setString(1, giftID);
            stmt.executeUpdate();
        }
        catch(SQLException ex)
        {
            JOptionPane.showMessageDialog(null, ex.getMessage(),"Error",JOptionPane.ERROR_MESSAGE);
        }
    }
}
