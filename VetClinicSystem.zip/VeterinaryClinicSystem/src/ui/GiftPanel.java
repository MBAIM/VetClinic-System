package ui;

/**
 *
 * @author MORRIS
 */
import control.MaintainGift;
import domain.Gift;
import domain.Staff;
import domain.TableModel;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

public class GiftPanel extends javax.swing.JPanel {
          MaintainGift giftControl; 
    /**
     * Creates new form giftPanel
     */
    public GiftPanel() {
        initComponents();
        giftControl = new MaintainGift();
        jtfGiftId.setEnabled(false);
        jtfSearch.setOpaque(false);
        
        jtfSearch.setBackground(new Color(255,255,255,127));
//        jtfSearch.setBorder(null);
        setDynamicPanel();
    }
    
    public void setDynamicPanel() {
        JPanel targetPanel = new JPanel();
        if(MainMenu.action.equals("add")){
             targetPanel=jpAdd;
             jbtConfirmChange.setVisible(false);
             jbtConfirmDelete.setVisible(false);
             jbtAddGift.setVisible(true);
             jtfGiftId.setText(generateGiftId());
             jlblGift.setText("Add Gift");
        }
        else if (MainMenu.action.equals("search")){
            targetPanel=jpSearch;
            jbtModifyGift.setVisible(false);
            jbtDeleteGift.setVisible(false);
            jbtView.setVisible(true);
            jlblGift.setText("Search Gift");
        }
        else if(MainMenu.action.equals("modifySelected")){
             targetPanel=jpAdd;
             jbtConfirmChange.setVisible(true);
             jbtConfirmDelete.setVisible(false);
             jbtAddGift.setVisible(false);
             jlblGift.setText("Modify Gift");
        
        }else if(MainMenu.action.equals("deleteSelected")){
             targetPanel=jpAdd;
             jbtConfirmChange.setVisible(false);
             jbtConfirmDelete.setVisible(true);
             jbtAddGift.setVisible(false);
             jlblGift.setText("Delete Gift");
             
        }else if(MainMenu.action.equals("modify")){
                targetPanel=jpSearch;
                jbtDeleteGift.setVisible(false);
                jbtModifyGift.setVisible(true);
                jbtView.setVisible(false);
                jlblGift.setText("Modify Gift");
        }
        else if(MainMenu.action.equals("delete")){
                targetPanel=jpSearch;
                jbtModifyGift.setVisible(false);
                jbtDeleteGift.setVisible(true);
                jbtView.setVisible(false);
                jlblGift.setText("Delete Gift");
                
        }else if(MainMenu.action.equals("viewSelected")){
             targetPanel=jpAdd;
             jbtConfirmChange.setVisible(false);
             jbtConfirmDelete.setVisible(false);
             jbtAddGift.setVisible(false);
             jlblGift.setText("View Gift");

        }
        
        dynamicPanel.removeAll();
        dynamicPanel.repaint();
        dynamicPanel.revalidate();
            
        //Adding Pannel
        dynamicPanel.add(targetPanel);
        dynamicPanel.repaint();
        dynamicPanel.revalidate();
    }
    
    public void fillFields(Gift gift){
     
    jtfPrice.setText(""+gift.getUnitPrice());
    jtfGiftId.setText(gift.getGiftID());
    jtfTitle.setText(gift.getGiftTitle());
    jtaDescrip.setText(gift.getGiftDesp());
     }
    
    public void disableFields(){
    
        jtfPrice.setEditable(false);
        jtfGiftId.setEditable(false);
        jtfTitle.setEditable(false);
        jtaDescrip.setEditable(false);
    }
    public Gift validateInput(){
    
    Gift gift;
    boolean valid =true; 
    
    Double price = Double.parseDouble(jtfPrice.getText());
    String giftid = jtfGiftId.getText();
    String title = jtfTitle.getText();
    String descrip = jtaDescrip.getText();
    
    valid = price.equals(null)?false:true; //need
    valid = giftid.equals(null)?false:true;
    valid = title.equals(null)?false:true;
    valid = descrip.equals(null)?false:true;
    
    if(valid==true){
         
           // take object domain constructor and initialiue (pass value) 
           gift = new Gift(giftid, title, price, descrip);
         }
         else {
             gift=null;
         }
         
         return gift;
    }

    public void resetFields(){
    
    jtfPrice.setText("");
    jtfSearch.setText("");
    jtfGiftId.setText("");
    jtfTitle.setText("");
    jtaDescrip.setText("");
    }
    
    public String generateGiftId(){
        ArrayList<Gift> giftList = giftControl.searchRecord("", 0);
        ArrayList<Integer> idList = new ArrayList<Integer>(); 
        //implement sorting 
        
        for(int i=0; i<giftList.size(); i++){
        String idStr = giftList.get(i).getGiftID();
        int idNo = Integer.parseInt(idStr.split("G")[1]);
        idList.add(idNo);
        }
        
        Collections.sort(idList);
        int idNo = 1; 
        for(int i=0; i<idList.size(); i++){
            if(idList.get(i)!=i+1){
                idNo=i+1;
                break;
            }
            if(i==idList.size()-1){
                idNo=idList.size()+1; 
            }
        } 
        
        String zeroes = "";
        if(idNo>999){zeroes="";}
        else if(idNo>99){zeroes="0";}
        else if(idNo>9){zeroes="00";}
        else if (idNo>0){zeroes="000";}
        return "G"+zeroes+idNo;
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jlblSearch = new javax.swing.JLabel();
        jtfSearch = new javax.swing.JTextField();
        jlblGift = new javax.swing.JLabel();
        dynamicPanel = new javax.swing.JPanel();
        jpSearch = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jtGift = new javax.swing.JTable();
        jbtModifyGift = new javax.swing.JButton();
        jbtDeleteGift = new javax.swing.JButton();
        jbtView = new javax.swing.JButton();
        jpAdd = new javax.swing.JPanel();
        jlblId = new javax.swing.JLabel();
        jtfGiftId = new javax.swing.JTextField();
        jlblTitle = new javax.swing.JLabel();
        jtfPrice = new javax.swing.JTextField();
        jlblPrice = new javax.swing.JLabel();
        jtfTitle = new javax.swing.JTextField();
        jlblDescrip = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtaDescrip = new javax.swing.JTextArea();
        jbtAddGift = new javax.swing.JButton();
        jbtConfirmChange = new javax.swing.JButton();
        jbtConfirmDelete = new javax.swing.JButton();

        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(229, 204, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jlblSearch.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jlblSearch.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/search.png"))); // NOI18N
        jlblSearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jlblSearchMouseClicked(evt);
            }
        });
        jPanel2.add(jlblSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 30, 40, 30));

        jtfSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtfSearchActionPerformed(evt);
            }
        });
        jPanel2.add(jtfSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 30, 260, 30));

        jlblGift.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        jlblGift.setText("Gift");
        jPanel2.add(jlblGift, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 30, 180, -1));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 880, 70));

        dynamicPanel.setLayout(new java.awt.CardLayout());

        jpSearch.setBackground(new java.awt.Color(229, 204, 255));
        jpSearch.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jtGift.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Gift ID", "Title", "Unitn Price", "Description"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.Double.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(jtGift);

        jpSearch.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 40, 550, 230));

        jbtModifyGift.setText("Modify Gift");
        jbtModifyGift.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jbtModifyGiftMouseClicked(evt);
            }
        });
        jbtModifyGift.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtModifyGiftActionPerformed(evt);
            }
        });
        jpSearch.add(jbtModifyGift, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 320, -1, -1));

        jbtDeleteGift.setText("Delete Gift");
        jbtDeleteGift.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jbtDeleteGiftMouseClicked(evt);
            }
        });
        jbtDeleteGift.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtDeleteGiftActionPerformed(evt);
            }
        });
        jpSearch.add(jbtDeleteGift, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 320, -1, -1));

        jbtView.setText("View Gift");
        jbtView.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtViewActionPerformed(evt);
            }
        });
        jpSearch.add(jbtView, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 320, -1, -1));

        dynamicPanel.add(jpSearch, "card3");

        jpAdd.setBackground(new java.awt.Color(229, 204, 255));
        jpAdd.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jlblId.setText("Gift  ID :");
        jpAdd.add(jlblId, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 60, -1, -1));

        jtfGiftId.setToolTipText("Enter service ID");
        jpAdd.add(jtfGiftId, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 60, 90, -1));

        jlblTitle.setText("Gift Title :");
        jpAdd.add(jlblTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 100, -1, -1));

        jtfPrice.setToolTipText("Enter price");
        jpAdd.add(jtfPrice, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 60, 70, -1));

        jlblPrice.setText("Unit Price (Ksh) :");
        jpAdd.add(jlblPrice, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 60, -1, -1));

        jtfTitle.setToolTipText("Enter service title");
        jpAdd.add(jtfTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 100, 290, -1));

        jlblDescrip.setText("Gift Description:");
        jpAdd.add(jlblDescrip, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 140, -1, -1));

        jtaDescrip.setColumns(20);
        jtaDescrip.setRows(5);
        jScrollPane1.setViewportView(jtaDescrip);

        jpAdd.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 140, 290, 120));

        jbtAddGift.setText("Add Gift");
        jbtAddGift.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtAddGiftActionPerformed(evt);
            }
        });
        jpAdd.add(jbtAddGift, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 300, -1, -1));

        jbtConfirmChange.setText("Confirm Changes");
        jbtConfirmChange.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jbtConfirmChangeMouseClicked(evt);
            }
        });
        jbtConfirmChange.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtConfirmChangeActionPerformed(evt);
            }
        });
        jpAdd.add(jbtConfirmChange, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 300, -1, -1));

        jbtConfirmDelete.setText("Confirm Delete");
        jbtConfirmDelete.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jbtConfirmDeleteMouseClicked(evt);
            }
        });
        jbtConfirmDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtConfirmDeleteActionPerformed(evt);
            }
        });
        jpAdd.add(jbtConfirmDelete, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 300, -1, -1));

        dynamicPanel.add(jpAdd, "card2");

        jPanel1.add(dynamicPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 69, 970, 480));

        add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 880, 560));
    }// </editor-fold>//GEN-END:initComponents

    private void jlblSearchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlblSearchMouseClicked
        // TODO add your handling code here:
        //I used all my 洪荒之力 to make this method

        jtGift.setModel(new DefaultTableModel());
        jtGift.repaint();

        if(MainMenu.action == "modifySelected"){
            MainMenu.action="modify";
        }
        else if(MainMenu.action == "deleteSelected"){
            MainMenu.action="delete";
        }else if(MainMenu.action == "add"||MainMenu.action == "viewSelected" ){
            MainMenu.action="search";
        }
        setDynamicPanel();

        String queryStr =jtfSearch.getText().toUpperCase();
        int option =0;

        if(Pattern.matches("G\\d{4}", queryStr)){
            option=1;
        }

        else{
            option=2;
        }
        ArrayList<Gift> itemList = giftControl.searchRecord(queryStr,option);

        //        MainMenu.action="search";

        if(itemList.size()!=0&&itemList!=null){
            Object[][] data = new Object[100][8];
            for(int i=0; i<itemList.size();i++){
                data[i] = itemList.get(i).getObjects();
            }
            String[] columnNames = {"Gift ID","Title","Unit Price","Description"};
            TableModel tModel = new TableModel(data, columnNames);
            jtGift.setModel(tModel);
            jtGift.createDefaultColumnsFromModel();
            jtGift.repaint();
        }
        else{
            JOptionPane.showMessageDialog(null, "No results found!" , "No such record.", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jlblSearchMouseClicked

    private void jtfSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtfSearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtfSearchActionPerformed

    private void jbtModifyGiftMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jbtModifyGiftMouseClicked
        // TODO add your handling code here:
        MainMenu.action="modifySelected";
        Gift selectedItem=null;
        if(jtGift.getSelectedRow()>=0 ) {
            String ic  = (String) jtGift.getValueAt(jtGift.getSelectedRow(),0);
            selectedItem = giftControl.searchRecord(ic);
            if(selectedItem!=null){
                setDynamicPanel();
                fillFields(selectedItem);
            }
        }
        else{
            JOptionPane.showMessageDialog(null,"Please search and select the record you wish to modify","Empty selection",JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jbtModifyGiftMouseClicked

    private void jbtModifyGiftActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtModifyGiftActionPerformed
        // TODO add your handling code here:
        MainMenu.action="modifySelected";
        Gift selectedGift=null;
        if(jtGift.getSelectedRow()>=0 ) {
            String id  = (String) jtGift.getValueAt(jtGift.getSelectedRow(),0);
           selectedGift = giftControl.searchRecord(id);
            if(selectedGift!=null){
                setDynamicPanel();
                fillFields(selectedGift);
            }
            else{
                JOptionPane.showMessageDialog(null,"Please search and select the record you wish to modify","Empty selection",JOptionPane.ERROR_MESSAGE);
            }
        }
        else{
            JOptionPane.showMessageDialog(null,"Please search and select the record you wish to modify","Empty selection",JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jbtModifyGiftActionPerformed

    private void jbtDeleteGiftMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jbtDeleteGiftMouseClicked
        // TODO add your handling code here:
        MainMenu.action="delete";
        Gift selectedGift=null;
        if(jtGift.getSelectedRow()>=0 ) {
            String ic  = (String) jtGift.getValueAt(jtGift.getSelectedRow(),0);
            selectedGift = giftControl.searchRecord(ic);

        }
        else{
            JOptionPane.showMessageDialog(null,"Please search and select the record you wish to delete","Empty selection",JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jbtDeleteGiftMouseClicked

    private void jbtDeleteGiftActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtDeleteGiftActionPerformed
        // TODO add your handling code here:
        MainMenu.action="deleteSelected";
        Gift selectedGift=null;
        if(jtGift.getSelectedRow()>=0 ) {
            String id  = (String) jtGift.getValueAt(jtGift.getSelectedRow(),0);
            selectedGift = giftControl.searchRecord(id);
            if(selectedGift!=null){
                setDynamicPanel();
                fillFields(selectedGift);
                jtfSearch.setEnabled(false);
                jtaDescrip.setEnabled(false);
                jbtDeleteGift.setEnabled(false);
                jbtModifyGift.setEnabled(false);
                jtfPrice.setEnabled(false);
                jtfSearch.setEnabled(false);
                jtfGiftId.setEnabled(false);
                jtfTitle.setEnabled(false);

            }
        }
        else{
            JOptionPane.showMessageDialog(null,"Please search and select the record you wish to modify","Empty selection",JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jbtDeleteGiftActionPerformed

    private void jbtViewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtViewActionPerformed
        // TODO add your handling code here:
        MainMenu.action="viewSelected";
        Gift selectedGift=null;
        if(jtGift.getSelectedRow()>=0 ) {
            String id  = (String) jtGift.getValueAt(jtGift.getSelectedRow(),0);
            selectedGift = giftControl.searchRecord(id);
            if(selectedGift!=null){
                setDynamicPanel();
                fillFields(selectedGift);
                disableFields();
            }
            else{
                JOptionPane.showMessageDialog(null,"Please search and select the record you wish to view.","Empty selection",JOptionPane.ERROR_MESSAGE);
            }
        }
        else{
            JOptionPane.showMessageDialog(null,"Please search and select the record you wish to view.","Empty selection",JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jbtViewActionPerformed

    private void jbtAddGiftActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtAddGiftActionPerformed
        // TODO add your handling code here:
        Gift gift = validateInput();
        if(gift!=null){
            //write to database
            Gift s = giftControl.searchRecord(gift.getGiftID());

            if(s != null)
            {
                JOptionPane.showMessageDialog(null,"This staff already exist.", "Duplicate Record", JOptionPane.ERROR_MESSAGE);
            }
            else
            {
                s = gift;
                try{
                    giftControl.addRecord(s);
                    resetFields();
                    JOptionPane.showMessageDialog(null,"New Gift is created.","Success",JOptionPane.INFORMATION_MESSAGE);
                    jtfGiftId.setText(generateGiftId());
                }
                catch (Exception ex){
                    JOptionPane.showMessageDialog(null,ex.getMessage(),"Failure",JOptionPane.ERROR_MESSAGE);
                }
            }

        }
        else{
            int reply =JOptionPane.showConfirmDialog(this.getParent().getParent().getParent(), "Your input seems to have data that is invalid or in incorrect format. Would you like to reset all fields?", "Invalid Data!", JOptionPane.YES_NO_OPTION, JOptionPane.ERROR_MESSAGE);

            if(reply==JOptionPane.YES_OPTION){
                resetFields();
            }
        }
    }//GEN-LAST:event_jbtAddGiftActionPerformed

    private void jbtConfirmChangeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jbtConfirmChangeMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtConfirmChangeMouseClicked

    private void jbtConfirmChangeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtConfirmChangeActionPerformed
        // TODO add your handling code here:
       Gift item = validateInput();
        if(item!=null){
            //write to database ****
            Gift s = giftControl.searchRecord(item.getGiftID());

            if(s == null)
            {
                JOptionPane.showMessageDialog(null,"This Gift does not exist.", "Record Not Found", JOptionPane.ERROR_MESSAGE);
            }
            else
            {
                s = item;
                int reply =JOptionPane.showConfirmDialog(this.getParent().getParent().getParent(), "Are you sure you want commit the changes made?", "Confirm changes?", JOptionPane.YES_NO_OPTION, JOptionPane.ERROR_MESSAGE);

                if(reply==JOptionPane.YES_OPTION){
                    try{
                        giftControl.updateRecord(s);
                        resetFields();
                        JOptionPane.showMessageDialog(null,"Gift details of gift "+ item.getGiftID()+" has been updated.","Success",JOptionPane.INFORMATION_MESSAGE);
                    }
                    catch (Exception ex){
                        JOptionPane.showMessageDialog(null,ex.getMessage(),"Failure",JOptionPane.ERROR_MESSAGE);
                    }
                }
            }

            //---*****
        }
        else{
            //****
            int reply =JOptionPane.showConfirmDialog(this.getParent().getParent().getParent(), "Your input seems to have data that is invalid or in incorrect format. Would you like to reset all fields?", "Invalid Data!", JOptionPane.YES_NO_OPTION, JOptionPane.ERROR_MESSAGE);

            if(reply==JOptionPane.YES_OPTION){
                resetFields();
            }
            //***
        }

    }//GEN-LAST:event_jbtConfirmChangeActionPerformed

    private void jbtConfirmDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtConfirmDeleteActionPerformed
        // TODO add your handling code here:
        Gift gift = validateInput();
            if(gift!=null){
                Gift s = giftControl.searchRecord(gift.getGiftID());

                if(s == null)
                {
                    JOptionPane.showMessageDialog(null,"This gift does not exist.", "Record Not Found", JOptionPane.ERROR_MESSAGE);
                }
                else
                {
                    s = gift;
                    int reply =JOptionPane.showConfirmDialog(this.getParent().getParent().getParent(), "Are you sure you want delete service "+gift.getGiftID()+" ?", "Confirm delete?", JOptionPane.YES_NO_OPTION, JOptionPane.ERROR_MESSAGE);

                    if(reply==JOptionPane.YES_OPTION){
                        try{
                            giftControl.deleteRecord(s.getGiftID());
                            resetFields();
                            JOptionPane.showMessageDialog(null,"Gift "+ gift.getGiftID()+" has been deleted.","Success",JOptionPane.INFORMATION_MESSAGE);
                        }
                        catch (Exception ex){
                            JOptionPane.showMessageDialog(null,ex.getMessage(),"Failure",JOptionPane.ERROR_MESSAGE);
                        }
                    }
                }

            }
            else{
                //****
                int reply =JOptionPane.showConfirmDialog(this.getParent().getParent().getParent(), "Your input seems to have data that is invalid or in incorrect format. Would you like to reset all fields?", "Invalid Data!", JOptionPane.YES_NO_OPTION, JOptionPane.ERROR_MESSAGE);

                if(reply==JOptionPane.YES_OPTION){
                    resetFields();
                }
            }                                          
    }//GEN-LAST:event_jbtConfirmDeleteActionPerformed

    private void jbtConfirmDeleteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jbtConfirmDeleteMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtConfirmDeleteMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel dynamicPanel;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton jbtAddGift;
    private javax.swing.JButton jbtConfirmChange;
    private javax.swing.JButton jbtConfirmDelete;
    private javax.swing.JButton jbtDeleteGift;
    private javax.swing.JButton jbtModifyGift;
    private javax.swing.JButton jbtView;
    private javax.swing.JLabel jlblDescrip;
    private javax.swing.JLabel jlblGift;
    private javax.swing.JLabel jlblId;
    private javax.swing.JLabel jlblPrice;
    private javax.swing.JLabel jlblSearch;
    private javax.swing.JLabel jlblTitle;
    private javax.swing.JPanel jpAdd;
    private javax.swing.JPanel jpSearch;
    private javax.swing.JTable jtGift;
    private javax.swing.JTextArea jtaDescrip;
    private javax.swing.JTextField jtfGiftId;
    private javax.swing.JTextField jtfPrice;
    private javax.swing.JTextField jtfSearch;
    private javax.swing.JTextField jtfTitle;
    // End of variables declaration//GEN-END:variables
}
